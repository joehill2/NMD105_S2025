let hue = ("darkblue")
let lightness = 20;

function setup() {
  createCanvas(400, 400);
  
} 

function draw() {
  background(220);
  stroke("black")
  
  
  //first row
  fill (hue)
  rect(0,0,80,80)
  rect(80,0,80,80)
  rect(160,0,80,80)
  rect(240,0,80,80)
  rect(320,0,80,80)
  
  //first block of row 2
  fill(`hsla(${hue},100%, ${lightness}, 1)`)
  rect(0,0,80,80)
  fill(20,20,20)
  rect(80,80,80,80)
  rect(160,80,80,80)
  rect(240,80,80,80)
  
  //last block of row 2
  fill(10,40,199)
  rect(320,80,80,80)
  fill(20,110,200)
  rect(0,160,80,80)
  fill(20,20,20)
  rect(80,160,80,80)
    
  //last three blocks of row 3
  fill(20,110,200)
  rect(160,160,80,80)
  rect(240,160,80,80)
  rect(320,160,80,80)
  //
  fill(60,150,210)
  rect(0,240,80,80)
  //
  fill(20,20,20)
  rect(80,240,80,80)
  //
  fill(20,20,20)
  rect(160,240,80,80)
  rect(240,240,80,80)
  //
  fill(60,150,200)
  rect(320,240,80,80)
  //
  fill(100,200,300)
  rect(0,320,80,80)
  rect(80,320,80,80)
  rect(160,320,80,80)
  rect(240,320,80,80)
  rect(320,320,80,80)
  
}